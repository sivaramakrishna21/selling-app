// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase: {
  apiKey: "AIzaSyAUTRp3AoL1g75dxJkHvyFeX1jFMKSm4PY",
  authDomain: "loginapp-3f7d2.firebaseapp.com",
  databaseURL: "https://loginapp-3f7d2.firebaseio.com",
  projectId: "loginapp-3f7d2",
  storageBucket: "loginapp-3f7d2.appspot.com",
  messagingSenderId: "889768961415",
  appId: "1:889768961415:web:01e2cdf08a84db47ae9f22",
  measurementId: "G-TXL2S4Z8DP"
}
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
