export const products=[
  {
    name:"redmi",
    description:"new launch of the year",
    cost:12999
  },
  {
    name:"realme x3 pro",
    description:"new launch of the year 2022",
    cost:23000
  },
  {
    name:"nokia new pro",
    description:"new launch of the year 2023",
    cost:3600
  }

]
